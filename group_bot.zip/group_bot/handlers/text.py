

text1 = '''
Благодарим за заполнение анкеты 😊
Теперь ты можешь вступить в группы:
https://t.me/+dlEJYIy61w04ODIy
https://t.me/+L_2uMBsQWgAwMGUy
https://t.me/+L_2uMBsQWgAwMGUy
https://t.me/+xM7YpE7MKTk3MTF'''

text2 = '''
Чтобы получить одобрение на вступление - напиши одному из админов:

@GK_BC_MEZHGOROD

@transfermezhgorod

@TAXI_GK_MEZHGOROD
'''

